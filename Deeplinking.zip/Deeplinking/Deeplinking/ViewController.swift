//
//  ViewController.swift
//  Deeplinking
//
//  Created by Aditya Sinha on 11/03/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

